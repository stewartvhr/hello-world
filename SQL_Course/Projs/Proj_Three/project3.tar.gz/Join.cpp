#include "Join.hpp"
#include <functional>

/*
 * TODO: Student implementation
 * Input: Disk, Memory, Disk page ids for left relation, Disk page ids for right relation
 * Output: Vector of Buckets of size (MEM_SIZE_IN_PAGE - 1) after partition
 */

const int MEM_INPUT_BUFFER_ID = MEM_SIZE_IN_PAGE - 1;
const int MEM_OUTPUT_BUFFER_ID = MEM_SIZE_IN_PAGE - 2;

//Declerations for sub-functions of partition function
void partition_helper(Disk* disk,
                      Mem* mem,
                      vector<Bucket> &partitions, pair<unsigned int, unsigned int> rel,
                      std::string curr_rel);

void partition_hash_records(Disk* disk, Mem* mem, vector<Bucket> &partitions, Page * input_buffer, unsigned int curr_num_recs, std::string curr_rel);

void add_rel_record(vector<Bucket> &partitions, Page * curr_mem_page, Record curr_record,
                    std::string curr_rel, unsigned int curr_bucket);

void flush_rel_mem_buffers(Disk* disk, Mem* mem, vector<Bucket> &partitions,
                           std::string curr_rel);
//End of declerations for partition function sub-functions

//Declerations for probe sub-functions
void probe_hash_R_partition(Disk* disk, Mem* mem, Page * input_buffer, vector<unsigned int>R_partition);

void probe_hash_R_disk_records(Mem* mem, Page * input_buffer,
                               unsigned int num_disk_page_records);

void probe_R_partition_hash_table(Disk* disk, Mem* mem, Page * input_buffer, vector<unsigned int> S_partition, vector<unsigned int> * probe_disk_IDs, bool lrel_smaller);

void probe_w_S_disk_recs(Disk* disk, Mem* mem, Page * input_buffer,
                         vector<unsigned int> * probe_disk_IDs, unsigned int num_disk_page_records, bool lrel_smaller);

void reset_probe_mem_buffers(Mem* mem);

pair<bool, vector<unsigned int>> search_h2_mem_page(Page * curr_mem_page, Record curr_record);

void rec_matches_to_output_buffer(Disk* disk, Mem* mem, Page * curr_mem_page,
                                  Page * output_buffer, Record curr_record, vector<unsigned int> &rec_matches,
                                  vector<unsigned int> * probe_disk_IDs, bool lrel_smaller);

void add_output_rec_pair(Page * curr_mem_page, Page * output_buffer, Record curr_record,
                         unsigned int curr_rec_match_ID, bool lrel_smaller);

void flush_output_buffer(Disk * disk, Mem * mem, vector<unsigned int> * probe_disk_IDs);
//End of declerations for probe sub-functions

vector<Bucket> partition(
    Disk* disk, 
    Mem* mem, 
    pair<unsigned int, unsigned int> left_rel, 
    pair<unsigned int, unsigned int> right_rel)
{
    std::vector<Bucket> partitions(MEM_SIZE_IN_PAGE - 1, Bucket());
    
    std::string curr_rel = "R";
    
    partition_helper(disk, mem, partitions, left_rel, curr_rel);
    
    curr_rel = "S";
    
    partition_helper(disk, mem, partitions, right_rel, curr_rel);
    
    return partitions;
}

void partition_helper(Disk* disk,
                   Mem* mem,
                   vector<Bucket> &partitions, pair<unsigned int, unsigned int> rel,
               std::string curr_rel)
{
    unsigned int curr_num_recs = -1;

    Page * input_buffer = mem -> mem_page(MEM_INPUT_BUFFER_ID);
    
    for (unsigned int curr_disk_page_ID = rel.first; curr_disk_page_ID < rel.second;
         ++curr_disk_page_ID)
    {
        mem -> loadFromDisk(disk, curr_disk_page_ID, MEM_INPUT_BUFFER_ID);
        
        curr_num_recs = input_buffer -> size();
        
        partition_hash_records(disk, mem, partitions, input_buffer, curr_num_recs, curr_rel);
        
        input_buffer -> reset();
    }
    
    flush_rel_mem_buffers(disk, mem, partitions, curr_rel);
}

void partition_hash_records(Disk* disk, Mem* mem, vector<Bucket> &partitions, Page * input_buffer, unsigned int curr_num_recs, std::string curr_rel)
{
    unsigned int curr_bucket, curr_flush_disk_ID = -1;
    
    Page * curr_mem_page = nullptr;
    
    for (unsigned int curr_rec_ID = 0; curr_rec_ID < curr_num_recs; ++curr_rec_ID) {
        Record curr_record = input_buffer -> get_record(curr_rec_ID);
            
        curr_bucket = curr_record.partition_hash() % (MEM_SIZE_IN_PAGE - 1);
        
        curr_mem_page = mem -> mem_page(curr_bucket);
        
        if(curr_mem_page -> full())
        {
            curr_flush_disk_ID = mem -> flushToDisk(disk, curr_bucket);
            if(curr_rel == "R")
            {
                partitions[curr_bucket].add_left_rel_page(curr_flush_disk_ID);
            } else
            {
                partitions[curr_bucket].add_right_rel_page(curr_flush_disk_ID);
            }
        }
        add_rel_record(partitions, curr_mem_page, curr_record, curr_rel, curr_bucket);
    }
}

void add_rel_record(vector<Bucket> &partitions, Page * curr_mem_page, Record curr_record,
                         std::string curr_rel, unsigned int curr_bucket)
{
    curr_mem_page -> loadRecord(curr_record);
    if (curr_rel == "R")
    {
        ++partitions[curr_bucket].num_left_rel_record;
    } else
    {
        ++partitions[curr_bucket].num_right_rel_record;
    }
}

void flush_rel_mem_buffers(Disk* disk, Mem* mem, vector<Bucket> &partitions,
                           std::string curr_rel)
{
    unsigned int disk_page_ID, num_recs = -1;
    
    Page * mem_page = nullptr;
    
    for (unsigned int mem_page_ID = 0; mem_page_ID < MEM_SIZE_IN_PAGE - 1; ++mem_page_ID) {
        mem_page = mem -> mem_page(mem_page_ID);
        
        num_recs = mem_page -> size();
        
        if (num_recs > 0)
        {
            disk_page_ID = mem -> flushToDisk(disk, mem_page_ID);
            if (curr_rel == "R")
            {
                partitions[mem_page_ID].add_left_rel_page(disk_page_ID);
            } else
            {
                partitions[mem_page_ID].add_right_rel_page(disk_page_ID);
            }
        }
    }
}

/*
 * TODO: Student implementation
 * Input: Disk, Memory, Vector of Buckets after partition
 * Output: Vector of disk page ids for join result
 */
vector<unsigned int> probe(Disk* disk, Mem* mem, vector<Bucket>& partitions)
{
    vector<unsigned int> probe_disk_IDs;
    
    vector<unsigned int> curr_R_partition, curr_S_partition;
    
    unsigned int num_partitions = (unsigned int)partitions.size();
    
    Page * input_buffer = mem -> mem_page(MEM_INPUT_BUFFER_ID);
    
    for (unsigned int i = 0; i < num_partitions; ++i) {
        curr_R_partition = partitions[i].get_left_rel();
        
        curr_S_partition = partitions[i].get_right_rel();
        
        if (partitions[i].num_left_rel_record < partitions[i].num_right_rel_record)
        {
            probe_hash_R_partition(disk, mem, input_buffer, curr_R_partition);
            
            probe_R_partition_hash_table(disk, mem, input_buffer, curr_S_partition, &probe_disk_IDs, true);
            
            reset_probe_mem_buffers(mem);
        } else
        {
            probe_hash_R_partition(disk, mem, input_buffer, curr_S_partition);
            
            probe_R_partition_hash_table(disk, mem, input_buffer, curr_R_partition, &probe_disk_IDs, false);
            
            reset_probe_mem_buffers(mem);
        }
    }
    flush_output_buffer(disk, mem, &probe_disk_IDs);
    
    return probe_disk_IDs;
}

void probe_hash_R_partition(Disk* disk, Mem* mem, Page * input_buffer, vector<unsigned int>R_partition)
{
    unsigned int num_R_disk_pages = (unsigned int)R_partition.size();
    
    unsigned int num_disk_page_records = 0;
    
    unsigned int curr_disk_ID = -1;
    
    for (unsigned int i = 0; i < num_R_disk_pages; ++i) {
        curr_disk_ID = R_partition[i];
        
        mem -> loadFromDisk(disk, curr_disk_ID, MEM_INPUT_BUFFER_ID);
        
        num_disk_page_records = input_buffer -> size();

        probe_hash_R_disk_records(mem, input_buffer, num_disk_page_records);
        
        input_buffer -> reset();
    }
}

void probe_hash_R_disk_records(Mem* mem, Page * input_buffer,
                               unsigned int num_disk_page_records)
{
    unsigned int curr_bucket = -1;
    
    Page * curr_mem_page = nullptr;
    
    for (unsigned int curr_record_ID = 0; curr_record_ID < num_disk_page_records;
         ++curr_record_ID) {
        Record curr_record = input_buffer -> get_record(curr_record_ID);
        
        curr_bucket = curr_record.probe_hash() % (MEM_SIZE_IN_PAGE - 2);

        curr_mem_page = mem -> mem_page(curr_bucket);
        
        curr_mem_page -> loadRecord(curr_record);
    }
}

void probe_R_partition_hash_table(Disk* disk, Mem* mem, Page * input_buffer, vector<unsigned int> S_partition, vector<unsigned int> * probe_disk_IDs, bool lrel_smaller)
{
    unsigned int num_S_disk_pages = (unsigned int)S_partition.size();
    
    unsigned int num_disk_page_records = 0;
    
    unsigned int curr_disk_page_ID = -1;
    
    for (unsigned int i = 0; i < num_S_disk_pages; ++i) {
        curr_disk_page_ID = S_partition[i];
        
        mem -> loadFromDisk(disk, curr_disk_page_ID, MEM_INPUT_BUFFER_ID);
        
        num_disk_page_records = input_buffer -> size();
        
        probe_w_S_disk_recs(disk, mem, input_buffer, probe_disk_IDs, num_disk_page_records, lrel_smaller);
        
        input_buffer -> reset();
    }
}

void probe_w_S_disk_recs(Disk* disk, Mem* mem, Page * input_buffer,
                         vector<unsigned int> * probe_disk_IDs, unsigned int num_disk_page_records, bool lrel_smaller)
{
    unsigned int curr_bucket = -1;
    
    Page * curr_mem_page = nullptr;
    
    Page * output_buffer = mem -> mem_page(MEM_OUTPUT_BUFFER_ID);
    
    pair<bool, vector<unsigned int>> h2_mem_page_search_results;
    
    for (unsigned int curr_record_ID = 0; curr_record_ID < num_disk_page_records;
         ++curr_record_ID) {
        Record curr_record = input_buffer -> get_record(curr_record_ID);
        
        curr_bucket = curr_record.probe_hash() % (MEM_SIZE_IN_PAGE - 2);
        
        curr_mem_page = mem -> mem_page(curr_bucket);
        
        h2_mem_page_search_results = search_h2_mem_page(curr_mem_page, curr_record);
        
        if (h2_mem_page_search_results.first) {
            rec_matches_to_output_buffer(disk, mem, curr_mem_page, output_buffer, curr_record, h2_mem_page_search_results.second, probe_disk_IDs, lrel_smaller);
        }
    }
}

void reset_probe_mem_buffers(Mem* mem)
{
    Page * mem_buffer = nullptr;
    
    mem -> mem_page(MEM_INPUT_BUFFER_ID) -> reset();
    
    for (unsigned int mem_buffer_ID = 0; mem_buffer_ID < MEM_SIZE_IN_PAGE - 2; ++mem_buffer_ID)
    {
        mem_buffer = mem -> mem_page(mem_buffer_ID);
        mem_buffer -> reset();
    }
}

pair<bool, vector<unsigned int>> search_h2_mem_page(Page * curr_mem_page, Record curr_record)
{
    pair<bool, vector<unsigned int>> results;
    
    results.first = false;
    
    unsigned int num_records = curr_mem_page -> size();
    
    for (unsigned int rec_ID = 0; rec_ID < num_records; ++rec_ID)
    {
        if (curr_mem_page -> get_record(rec_ID) == curr_record) {
            if (results.second.size() == 0) {
                results.first = true;
            }
            results.second.push_back(rec_ID);
        }
    }
    return results;
}

void rec_matches_to_output_buffer(Disk* disk, Mem* mem, Page * curr_mem_page,
                                  Page * output_buffer, Record curr_record, vector<unsigned int> &rec_matches,
                                  vector<unsigned int> * probe_disk_IDs, bool lrel_smaller)
{
    unsigned int num_rec_matches = (unsigned int)rec_matches.size();
    
    unsigned int curr_rec_match_ID, curr_disk_ID = -1;
    
    for (unsigned int j = 0; j < num_rec_matches; ++j)
    {
        curr_rec_match_ID = rec_matches[j];
        
        if (output_buffer -> full()) {
           curr_disk_ID = mem -> flushToDisk(disk, MEM_OUTPUT_BUFFER_ID);
            probe_disk_IDs->push_back(curr_disk_ID);
        }
        add_output_rec_pair(curr_mem_page, output_buffer, curr_record, curr_rec_match_ID, lrel_smaller);
    }
}

void add_output_rec_pair(Page * curr_mem_page, Page * output_buffer, Record curr_record,
                         unsigned int curr_rec_match_ID, bool lrel_smaller)
{
    if (lrel_smaller)
    {
        output_buffer -> loadPair(curr_mem_page -> get_record(curr_rec_match_ID), curr_record);
    } else
    {
        output_buffer -> loadPair(curr_record,
                                  curr_mem_page -> get_record(curr_rec_match_ID));
    }
}

void flush_output_buffer(Disk * disk, Mem * mem, vector<unsigned int> * probe_disk_IDs)
{
    if (mem -> mem_page(MEM_OUTPUT_BUFFER_ID) -> size() > 0)
    {
        probe_disk_IDs -> push_back(mem->flushToDisk(disk, MEM_OUTPUT_BUFFER_ID));
    }
}

